﻿using Newtonsoft.Json;
using RESTConsumerWebApplication.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace RESTConsumerWebApplication.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        //Hosted web API REST Service base url  

        string Baseurl = "https://localhost:44337/"; // "http://192.168.95.1:5555/";

        //public async Task<ActionResult> Index()
        //{
        //    return View();
        //}

        public async Task<ActionResult> Index()
        {
            using (var client = new HttpClient())
            {
                List<JournalModel> JournalInfo = null;

                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();

                //Define request data format  
                //client.DefaultRequestHeaders.Add("Accept", "application/json");
                //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource Get using HttpClient  
                HttpResponseMessage Response = await client.GetAsync("api/dbvalues");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Response.IsSuccessStatusCode)
                {
                    //Storing the response details received from web api   
                    //var Result = Response.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the list  
                    //JournalInfo = JsonConvert.DeserializeObject<List<JournalModel>>(Result);

                    var Return = Response.Content.ReadAsStringAsync().Result;
                    JournalInfo = JsonConvert.DeserializeObject<List<JournalModel>>(Return);
                }

                //returning the list to view  
                return View(JournalInfo);
            }
        }
        public async Task<ActionResult> Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Create(JournalModel entry)
        {
            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();
                
                var json = JsonConvert.SerializeObject(entry);

                // serialize your json using newtonsoft json serializer then add it to the StringContent
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                //var content = new StringContent(json);

                // method address would be like api/callUber:SomePort for example
                var result = await client.PostAsync("api/dbvalues", content);
                string resultContent = await result.Content.ReadAsStringAsync();

                string message = "Created the record successfully";
                ViewBag.Message = message;

                //returning the list to view  
                return RedirectToAction("Index");
            }
        }

        public async Task<ActionResult> Edit(int? id)
        {
            using (var client = new HttpClient())
            {
                JournalModel JournalInfo = new JournalModel();

                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();

                //Define request data format  
                client.DefaultRequestHeaders.Add("Accept", "application/json");

                //Sending request to find web api REST service resource Get using HttpClient  
                HttpResponseMessage Response = await client.GetAsync("api/dbvalues" + "/" + id);

                //Checking the response is successful or not which is sent using HttpClient  
                if (Response.IsSuccessStatusCode)
                {
                    var Return = Response.Content.ReadAsStringAsync().Result;
                    JournalInfo = JsonConvert.DeserializeObject<JournalModel>(Return);
                }

                return View(JournalInfo);
            }
        }

        [HttpPost]
        public async Task<ActionResult> Edit(JournalModel entry)
        {
            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();

                var json = JsonConvert.SerializeObject(entry);

                // serialize your json using newtonsoft json serializer then add it to the StringContent
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
                //var content = new StringContent(json);

                // method address would be like api/callUber:SomePort for example
                var result = await client.PutAsync("api/dbvalues" + "/" + entry.Transaction_ID, content);
                string resultContent = await result.Content.ReadAsStringAsync();

                string message = "Updated the record successfully";
                ViewBag.Message = message;

                //returning the list to view  
                return RedirectToAction("Index");
            }
        }
        
        public async Task<ActionResult> Delete(int? id)
        {
            using (var client = new HttpClient())
            {
                JournalModel JournalInfo = new JournalModel();

                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();

                //Define request data format  
                client.DefaultRequestHeaders.Add("Accept", "application/json");

                //Sending request to find web api REST service resource Get using HttpClient  
                HttpResponseMessage Response = await client.GetAsync("api/dbvalues" + "/" + id);

                //Checking the response is successful or not which is sent using HttpClient  
                if (Response.IsSuccessStatusCode)
                {
                    var Return = Response.Content.ReadAsStringAsync().Result;
                    JournalInfo = JsonConvert.DeserializeObject<JournalModel>(Return);
                }

                return View(JournalInfo);
            }
        }

        [HttpPost, ActionName("Delete")]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();

                // method address would be like api/callUber:SomePort for example
                var result = await client.DeleteAsync("api/dbvalues" + "/" + id);
                string resultContent = await result.Content.ReadAsStringAsync();

                string message = "Deleted the record successfully";
                ViewBag.Message = message;

                //returning the list to view  
                return RedirectToAction("Index");
            }
        }
    }
}