﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RESTConsumerWebApplication.Models
{
    public class JournalModel
    {
        [Display(Name = "No.")]
        public int Transaction_ID { get; set; }

        [Display(Name = "Date")]
        public DateTime Transaction_Date { get; set; }

        [Display(Name = "Details")]
        public string Transaction_Details { get; set; }

        [Display(Name = "Debit Amt.")]
        public decimal Transaction_Debit { get; set; }

        [Display(Name = "Credit Amt.")]
        public decimal Transaction_Credit { get; set; }

    }
}